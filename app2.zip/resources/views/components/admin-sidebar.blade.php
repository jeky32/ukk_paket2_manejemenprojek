<!-- resources/views/components/admin-sidebar.blade.php -->
<aside class="w-64 bg-white shadow-lg min-h-screen">
    <div class="p-4 border-b border-gray-200">
        <!-- Logo -->
        <div class="flex items-center space-x-3">
            <div class="w-10 h-10 bg-blue-600 rounded-lg flex items-center justify-center">
                <span class="text-white font-bold text-lg">PM</span>
            </div>
            <div>
                <h1 class="text-lg font-bold text-gray-800">Project Manager</h1>
                <p class="text-xs text-gray-500">Admin Panel</p>
            </div>
        </div>
    </div>

    <!-- User Info -->
    <div class="p-4 border-b border-gray-200 bg-blue-50">
        <div class="flex items-center space-x-3">
            <div class="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center">
                <span class="text-white font-semibold text-sm">
                    {{ strtoupper(substr(Auth::user()->username, 0, 2)) }}
                </span>
            </div>
            <div class="flex-1 min-w-0">
                <p class="text-sm font-medium text-gray-900 truncate">
                    {{ Auth::user()->full_name ?: Auth::user()->username }}
                </p>
                <p class="text-xs text-gray-500 capitalize">{{ Auth::user()->role }}</p>
            </div>
        </div>
    </div>

    <!-- Navigation Menu -->
    <nav class="p-4">
        <ul class="space-y-2">
            <!-- Dashboard -->
            <li>
                <a href="{{ route('admin.dashboard') }}" 
                   class="flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors 
                          {{ request()->routeIs('admin.dashboard') ? 'bg-blue-100 text-blue-600' : 'text-gray-700 hover:bg-gray-100' }}">
                    <i class="fas fa-tachometer-alt w-5 text-center"></i>
                    <span>Dashboard</span>
                </a>
            </li>

            <!-- Projects -->
            <li>
                <a href="{{ route('admin.projects.index') }}" 
                   class="flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors 
                          {{ request()->routeIs('admin.projects.*') ? 'bg-blue-100 text-blue-600' : 'text-gray-700 hover:bg-gray-100' }}">
                    <i class="fas fa-folder w-5 text-center"></i>
                    <span>Projects</span>
                </a>
            </li>

            <!-- Manajemen Proyek -->
            <li>
                <a href="{{ route('admin.projects.index') }}" 
                   class="flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors 
                          {{ request()->routeIs('admin.projects.*') ? 'bg-blue-100 text-blue-600' : 'text-gray-700 hover:bg-gray-100' }}">
                    <i class="fas fa-project-diagram w-5 text-center"></i>
                    <span>Manajemen Proyek</span>
                </a>
            </li>

            <!-- Monitoring -->
            <li>
                <a href="{{ route('admin.monitoring.index') }}" 
                   class="flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors 
                          {{ request()->routeIs('admin.monitoring.*') ? 'bg-blue-100 text-blue-600' : 'text-gray-700 hover:bg-gray-100' }}">
                    <i class="fas fa-chart-bar w-5 text-center"></i>
                    <span>Monitoring</span>
                </a>
            </li>

            <!-- Manajemen User -->
            <li>
                <a href="{{ route('admin.users.index') }}" 
                   class="flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors 
                          {{ request()->routeIs('admin.users.*') ? 'bg-blue-100 text-blue-600' : 'text-gray-700 hover:bg-gray-100' }}">
                    <i class="fas fa-users w-5 text-center"></i>
                    <span>Manajemen User</span>
                </a>
            </li>

            <!-- Reports -->
            <li>
                <a href="#" 
                   class="flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors text-gray-700 hover:bg-gray-100">
                    <i class="fas fa-chart-pie w-5 text-center"></i>
                    <span>Laporan</span>
                </a>
            </li>

            <!-- Separator -->
            <li class="pt-4">
                <div class="border-t border-gray-200"></div>
            </li>

            <!-- Settings -->
            <li>
                <a href="#" 
                   class="flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors text-gray-700 hover:bg-gray-100">
                    <i class="fas fa-cog w-5 text-center"></i>
                    <span>Pengaturan</span>
                </a>
            </li>

            <!-- Logout -->
            <li>
                <form method="POST" action="{{ route('logout') }}" class="w-full">
                    @csrf
                    <button type="submit" 
                            class="flex items-center space-x-3 px-3 py-2 rounded-lg transition-colors text-gray-700 hover:bg-gray-100 w-full text-left">
                        <i class="fas fa-sign-out-alt w-5 text-center"></i>
                        <span>Keluar</span>
                    </button>
                </form>
            </li>
        </ul>
    </nav>

    <!-- Quick Stats -->
    <div class="p-4 border-t border-gray-200 bg-gray-50">
        <div class="space-y-3">
            <div class="text-center">
                <p class="text-2xl font-bold text-gray-800">{{ \App\Models\Project::count() }}</p>
                <p class="text-xs text-gray-500">Total Proyek</p>
            </div>
            <div class="text-center">
                <p class="text-2xl font-bold text-gray-800">{{ \App\Models\User::count() }}</p>
                <p class="text-xs text-gray-500">Total User</p>
            </div>
        </div>
    </div>
</aside>